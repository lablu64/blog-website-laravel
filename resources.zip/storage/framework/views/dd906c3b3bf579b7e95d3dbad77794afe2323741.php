<div class="oc-bg">
    <div class="timerpro container">
        <h1 class="heading text-center"><strong>Special product</strong><span>deal of the day</span><span class="head-svg"><svg><use xlink:href="#hsvg"></use></svg></span></h1>
       <div class="row rless"> 
            <div class="count-bag">
               <div id="count" class="owl-theme owl-carousel">
                    <div class="product-layout col-xs-12 cless">
                     <div class="product-thumb transition">
  
                        <div class="image col-xs-5">
                          <div class="oc_bor">
                          <a href="index.php-23.html?route=product/product&amp;product_id=30"><img src="<?php echo e(asset('frontend/image/cache/catalog/product/3-800x800.jpg')); ?>" alt="38024PP25 Minimalists Analog Watch" title="38024PP25 Minimalists Analog Watch" class="img-responsive center-block"></a>
  
           
                              <!--         <span class="sale">10%</span>
                              -->
  
                                 <!--   <span class="reduce-price">reduced price</span> -->
                         </div>
                     </div>
       
                    <div class="caption col-xs-7">
  
                      <div class="bran">
                              <span>fresh fruit, Canon</span>
                      </div>
                              <h4 class="protitle"><a href="index.php-23.html?route=product/product&amp;product_id=30">38024PP25 Minimalists Analog Watch</a></h4>
                              <div class="price">
                                  <span class="price-new">$110.00</span> <span class="price-old">$122.00</span>
                                      </div>
                                  
                  <div class="all-timer">
                              <div id="Countdown42" class="box-timer is-countdown"><span class="countdown-row countdown-show4 "><span class="countdown-section"><span class="countdown-amount">758</span><span class="countdown-period">Days</span></span><span class="countdown-section"><span class="countdown-amount">8</span><span class="countdown-period">Hrs</span></span><span class="countdown-section"><span class="countdown-amount">21</span><span class="countdown-period">Mins</span></span><span class="countdown-section"><span class="countdown-amount">30</span><span class="countdown-period">Secs</span></span></span></div> 
                  </div>
                              
                          </div>
                      </div>
                  </div>
                  <div class="product-layout col-xs-12 cless">
                      <div class="product-thumb transition">
  
                      <div class="image col-xs-5">
                          <div class="oc_bor">
                          <a href="index.php-24.html?route=product/product&amp;product_id=42"><img src="<?php echo e(asset('frontend/image/cache/catalog/product/1-800x800.jpg')); ?>" alt="Apple Cinema 30&quot;" title="Apple Cinema 30&quot;" class="img-responsive center-block"></a>
  
                          
                          <!--  -->
  
                                              </div>
                      </div>
                      
                      <div class="caption col-xs-7">
  
                          <div class="bran">
                                  <span>fresh fruit, Apple</span>
                          </div>
                                  <h4 class="protitle"><a href="index.php-24.html?route=product/product&amp;product_id=42">Apple Cinema 30&quot;</a></h4>
                                  <div class="price">
                                      $122.00
                                          </div>
                                      
                      <div class="all-timer">
                                  <div id="Countdown42" class="box-timer is-countdown"><span class="countdown-row countdown-show4 "><span class="countdown-section"><span class="countdown-amount">758</span><span class="countdown-period">Days</span></span><span class="countdown-section"><span class="countdown-amount">8</span><span class="countdown-period">Hrs</span></span><span class="countdown-section"><span class="countdown-amount">21</span><span class="countdown-period">Mins</span></span><span class="countdown-section"><span class="countdown-amount">30</span><span class="countdown-period">Secs</span></span></span></div> 
                      </div>
                      
                      </div>
  
                      
                      
  
                              </div>
                   </div>
                  <div class="product-layout col-xs-12 cless">
                      <div class="product-thumb transition">
  
                      <div class="image col-xs-5">
                          <div class="oc_bor">
                          <a href="index.php-25.html?route=product/product&amp;product_id=47"><img src="<?php echo e(asset('frontend/image/cache/catalog/product/5-800x800.jpg')); ?>" alt="Amkette Evo Gamepad Pro 4 with Instant Play Blueto..." title="Amkette Evo Gamepad Pro 4 with Instant Play Blueto..." class="img-responsive center-block"></a>
  
                          
                          <!--  -->
  
                                              </div>
                      </div>
                      
                      <div class="caption col-xs-7">
  
                          <div class="bran">
                                  <span>fresh fruit, Apple</span>
                          </div>
                                  <h4 class="protitle"><a href="index.php-25.html?route=product/product&amp;product_id=47">Amkette Evo Gamepad Pro 4 with Instant Play Blueto...</a></h4>
                                  <div class="price">
                                      $122.00
                                          </div>
                                      
                      <div class="all-timer">
                                  <div id="Countdown42" class="box-timer is-countdown"><span class="countdown-row countdown-show4 "><span class="countdown-section"><span class="countdown-amount">758</span><span class="countdown-period">Days</span></span><span class="countdown-section"><span class="countdown-amount">8</span><span class="countdown-period">Hrs</span></span><span class="countdown-section"><span class="countdown-amount">21</span><span class="countdown-period">Mins</span></span><span class="countdown-section"><span class="countdown-amount">30</span><span class="countdown-period">Secs</span></span></span></div> 
                      </div>
                      
                      </div>
  
                      
                      
  
                              </div>
                  </div>
                  <div class="product-layout col-xs-12 cless">
                          <div class="product-thumb transition">
  
                          <div class="image col-xs-5">
                              <div class="oc_bor">
                              <a href="index.php-26.html?route=product/product&amp;product_id=33"><img src="<?php echo e(asset('frontend/image/cache/catalog/product/31-800x800.jpg')); ?>" alt="Samsung SyncMaster 941BW" title="Samsung SyncMaster 941BW" class="img-responsive center-block"></a>
  
                              
                              <!--  -->
  
                                                  </div>
                          </div>
                          
                          <div class="caption col-xs-7">
  
                              <div class="bran">
                                      <span>fresh fruit, </span>
                              </div>
                                      <h4 class="protitle"><a href="index.php-26.html?route=product/product&amp;product_id=33">Samsung SyncMaster 941BW</a></h4>
                                      <div class="price">
                                          $242.00
                                              </div>
                                          
                          <div class="all-timer">
                                      <div id="Countdown42" class="box-timer is-countdown"><span class="countdown-row countdown-show4 "><span class="countdown-section"><span class="countdown-amount">758</span><span class="countdown-period">Days</span></span><span class="countdown-section"><span class="countdown-amount">8</span><span class="countdown-period">Hrs</span></span><span class="countdown-section"><span class="countdown-amount">21</span><span class="countdown-period">Mins</span></span><span class="countdown-section"><span class="countdown-amount">30</span><span class="countdown-period">Secs</span></span></span></div> 
                          </div>
                          
                          </div>
  
                          
                          
  
                                  </div>
                  </div>
                  <div class="product-layout col-xs-12 cless">
                          <div class="product-thumb transition">
  
                          <div class="image col-xs-5">
                              <div class="oc_bor">
                              <a href="index.php-27.html?route=product/product&amp;product_id=40"><img src="<?php echo e(asset('frontend/image/cache/catalog/product/12-800x800.jpg')); ?>" alt="ealme Narzo 10 (That Green, 128 GB)" title="ealme Narzo 10 (That Green, 128 GB)" class="img-responsive center-block"></a>
  
                              
                              <!--  -->
  
                                                  </div>
                          </div>
                          
                          <div class="caption col-xs-7">
  
                              <div class="bran">
                                      <span>fresh fruit, Apple</span>
                              </div>
                                      <h4 class="protitle"><a href="index.php-27.html?route=product/product&amp;product_id=40">ealme Narzo 10 (That Green, 128 GB)</a></h4>
                                      <div class="price">
                                          $123.20
                                              </div>
                                          
                          <div class="all-timer">
                                      <div id="Countdown42" class="box-timer is-countdown"><span class="countdown-row countdown-show4 "><span class="countdown-section"><span class="countdown-amount">758</span><span class="countdown-period">Days</span></span><span class="countdown-section"><span class="countdown-amount">8</span><span class="countdown-period">Hrs</span></span><span class="countdown-section"><span class="countdown-amount">21</span><span class="countdown-period">Mins</span></span><span class="countdown-section"><span class="countdown-amount">30</span><span class="countdown-period">Secs</span></span></span></div> 
                          </div>
                          
                          </div>
  
                          
                          
  
                          </div>
                  </div>
              
  
    
          </div>
  </div>
   </div>
  </div>
  </div>
  <script type="text/javascript">
     (function($){
      $("#count").owlCarousel({
      itemsCustom : [
      [0, 1],
      [400, 1],
      [600,2],
      [768, 2],
      [992, 2],
      [1200, 3],
      [1410, 3]
      ],
        // autoPlay: 1000,
        navigationText: ['<i class="fa fa-angle-left" aria-hidden="true"></i>', '<i class="fa fa-angle-right" aria-hidden="true"></i>'],
        navigation : true,
        pagination:false
      });
      }(jQuery));
  </script><?php /**PATH D:\xampp\htdocs\project20\project20\resources\views/frontend/includes/deal.blade.php ENDPATH**/ ?>