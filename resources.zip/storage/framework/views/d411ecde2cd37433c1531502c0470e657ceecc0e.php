<?php
$links = [
    [
        "href" => "dashboard",
        "text" => "Dashboard",
        "is_multi" => false,
    ],
    [
        "href" => [
            [
                "section_text" => "User",
                "section_list" => [
                    ["href" => "user", "text" => "Data User"],
                    ["href" => "user.new", "text" => "Buat User"]
                ]
            ]
        ],
        "text" => "User",
        "is_multi" => true,
    ],
];
$navigation_links = array_to_object($links);
?>

<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="<?php echo e(route('dashboard')); ?>">
                <img class="d-inline-block" width="32px" height="30.61px" src="" alt="">
            </a>
        </div>
        <?php $__currentLoopData = $navigation_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul class="sidebar-menu">
            <li class="menu-header"><?php echo e($link->text); ?></li>
            <?php if(!$link->is_multi): ?>
            <li class="<?php echo e(Request::routeIs($link->href) ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route($link->href)); ?>"><i class="fas fa-fire"></i><span>Dashboard</span></a>
            </li>
            <?php else: ?>
                <?php $__currentLoopData = $link->href; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $routes = collect($section->section_list)->map(function ($child) {
                        return Request::routeIs($child->href);
                    })->toArray();

                    $is_active = in_array(true, $routes);
                    ?>

                    <li class="dropdown <?php echo e(($is_active) ? 'active' : ''); ?>">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-chart-bar"></i> <span><?php echo e($section->section_text); ?></span></a>
                        <ul class="dropdown-menu">
                            <?php $__currentLoopData = $section->section_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="<?php echo e(Request::routeIs($child->href) ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route($child->href)); ?>"><?php echo e($child->text); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </aside>
</div>
<?php /**PATH D:\xampp\htdocs\project20\project20\resources\views/components/sidebar.blade.php ENDPATH**/ ?>