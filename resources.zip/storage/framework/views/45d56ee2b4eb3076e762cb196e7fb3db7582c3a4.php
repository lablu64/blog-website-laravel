

<?php $__env->startSection('title_admin'); ?>
All Show Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>  
<!-- Content -->

<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">All /</span> Category </h4>
    <a class="btn btn-success mb-2" href="<?php echo e(route('admin.category.create')); ?>"> Create Category</a>
   
    <!-- Basic Bootstrap Table -->
    <div class="card">
      <h5 class="card-header">All category </h5>
     
      <?php if(session('message')): ?>
    <h6 class="alert alert-success">
        <?php echo e(session('message')); ?>

    </h6>
   <?php endif; ?>
      <div class="table-responsive text-nowrap">
        <table class="table">
          <thead>
            <tr>
              <th>Sl</th>
              <th>Cateogry name</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody class="table-border-bottom-0">


          
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
                <tr>
                    <td><?php echo e($loop->index+1); ?></td>
                    <td> <i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo e($category->category_name); ?>

                    <br>
              
                    </td>
                    <td class="badge bg-label-<?php echo e($category->status == 'active'? 'primary':'danger'); ?> me-1"><?php echo e($category->status); ?></td>
                    <td>
                        <div class="dropdown">
                          <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                            <i class="bx bx-dots-vertical-rounded"></i>
                          </button>
                          <div class="dropdown-menu">
                            <a class="dropdown-item" href="<?php echo e(route('admin.category.edit',$category->id)); ?>"
                              ><i class="bx bx-edit-alt me-2"></i> Edit</a
                            >
                            <form action="<?php echo e(route('admin.category.destroy',$category->id)); ?>" method="POST">
                              <?php echo method_field('DELETE'); ?>
                              <?php echo csrf_field(); ?>
                              <button type="submit" class="dropdown-item show-alert-delete-box" ><i class="bx bx-trash me-2"></i> Delete</button>
                            </form>
                           
                          </div>
                        </div>
                      </td>                
                  </tr>
                   
              
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
           
          </tbody>
        </table>
      </div>
    </div>
    <!--/ Basic Bootstrap Table -->
    
    <!--/ Responsive Table -->
  </div>
  <!-- / Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project20\project20\resources\views/admin/category/index.blade.php ENDPATH**/ ?>