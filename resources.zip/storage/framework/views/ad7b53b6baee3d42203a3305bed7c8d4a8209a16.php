
<?php $__env->startSection('title_admin'); ?>
All Product Show 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>  
<!-- Content -->

<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">All /</span> Post </h4>
    <a class="btn btn-success mb-2" href="<?php echo e(route('admin.post.create')); ?>"> Create Post</a>
   
    <!-- Basic Bootstrap Table -->
    <div class="card">
      <h5 class="card-header">All Post List  </h5>
      <?php if(session('message')): ?>
      <h6 class="alert alert-success">
          <?php echo e(session('message')); ?>

      </h6>
     <?php endif; ?>
       <div class="table-responsive text-nowrap">
        <table class="table">
          <thead>
            <tr>
              <th>Sl</th>
              <th>Post Name</th>
    
              <th> Cateogry name</th>
              <th>Image</th>
              
              <th>Actions</th>
            </tr>
          </thead>
          <tbody class="table-border-bottom-0">
            
           <?php
              $i = $products->perPage() * ($products->currentPage() - 1);
           ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            
                <tr>
                  <td ><?php echo e($i+ $loop->index+1); ?></td>
                  
                  
                    <td> <i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo e(Str::limit(strip_tags($product->product_name ), 40)); ?></td>
                
                 
                    <td> <i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo e($product->category->category_name); ?></td>
                    <td><img height="50px;" src="<?php echo e(asset('public/'.$product->photo)); ?>" alt=""></td>
                   <td>
                        <div class="dropdown">
                          <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                            <i class="bx bx-dots-vertical-rounded"></i>
                          </button>
                          <div class="dropdown-menu">
                            <a class="dropdown-item" href="<?php echo e(route('admin.post.edit',$product->id)); ?>"
                              ><i class="bx bx-edit-alt me-2"></i> Edit</a>
                              <form action="<?php echo e(route('admin.post.destroy',$product->id)); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item " ><i class="bx bx-trash me-2"></i> Delete</button>
                              </form>
                            
                          </div>
                        </div>
                      </td>                
                  </tr>
                   
              
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
           
          </tbody>
        </table>
        <?php echo e($products->links('vendor.pagination.custom')); ?>

      </div>
    </div>
    <!--/ Basic Bootstrap Table -->
    
    <!--/ Responsive Table -->
  </div>
  <!-- / Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project20\project20\resources\views/admin/product/index.blade.php ENDPATH**/ ?>