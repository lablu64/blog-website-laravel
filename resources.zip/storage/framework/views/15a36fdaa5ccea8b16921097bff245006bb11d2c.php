 
 <?php $__env->startSection('title_admin'); ?>
 Create Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>      
       
       <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
                <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Post /</span> Create</h4>
  
                <!-- Basic Layout & Basic with Icons -->
                <div class="row">
                  <!-- Basic Layout -->
                  <div class="col-xxl">
                    <div class="card mb-4">
                      <div class="card-header d-flex align-items-center justify-content-between">
                        <h5 class="mb-0">Create Post  </h5>
                        
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <small class="text-muted float-end">input infromation </small>
                      </div>
                      <div class="card-body">
                        <form action="<?php echo e(route('admin.post.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                          <div class="row mb-3">
                            <label class="col-sm-2 col-form-label" for="product_name">Post  Name</label>
                            <div class="col-sm-10">
                              <input type="text" class="form-control" name="product_name" id="product_name" placeholder="Enter the post name" />
                            </div>
                          </div>

                          <div class="row mb-3">
                            <label class="col-sm-2 col-form-label" for="category_id">Category Name</label>
                            <div class="col-sm-10">
                              <select class="form-control" name="category_id" id="category_id">
                                <option value="0">category name</option>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"> <?php echo e($item->category_name); ?> </option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </select>
                            </div>
                          </div>


                          <div class="row mb-3">
                            <label class="col-sm-2 col-form-label" for="product_name"> Description  </label>
                            <div class="col-sm-10">
                                <textarea class="form-control" name="long_des" id="summernote" cols="30" rows="10"></textarea>
                            </div>
                          </div>

                       
                          <div class="row mb-3">
                            <label class="col-sm-2 col-form-label" for="photo">Image  </label>
                            <div class="col-sm-10">
                              <input type="file" class="form-control" name="photo" id="photo" placeholder=" stock " />
                            </div>
                          </div>

                    

              

                          <div class="row justify-content-end">
                            <div class="col-sm-10">
                              <button type="submit" class="btn btn-primary">create Post </button>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                
                </div>
              </div>

              
              <!-- / Content -->
<?php $__env->stopSection(); ?>  


<?php $__env->startPush('adminSubcategory'); ?>
<script>

$('#category_id').on('change', function () {
            var idCountry = this.value;
            $("#subcategory_id").html('');
            $.ajax({
                url: "<?php echo e(url('admin/getSubcategory')); ?>",
                type: "POST",
                data: {
                    category_id: idCountry,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                dataType: 'json',
                success: function (result) {
                    $('#subcategory_id').html('<option value="">-- Select subcategory --</option>');
                    $.each(result.states, function (key, value) {
                      console.log(value);
                        $("#subcategory_id").append('<option value="' + value
                            .id + '">' + value.subcategory_name + '</option>');
                    });
                  }
            });
        });


  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project20\project20\resources\views/admin/product/create.blade.php ENDPATH**/ ?>