<div id="common-home" class="container-fluid">
    <div class="row">
      <div id="content" class="col-xs-12">
          <div class="homeslider-container s-panel row">
        <div class="loader wrloader"></div>
         <div id="slideshow0" class="slideshow">
            <div>
                    <a href="#"><img src="<?php echo e(asset('frontend/image/cache/catalog/slider/slide-1-1920x900.jpg')); ?>" alt="iPhone 6" class="img-responsive center-block"></a>      <div class="slidertext">
                  <div class="slideff">
                      <h1>Organic fresh fruits for your health</h1> 
                      <p>Interdum et malesuada fames ac ante ipsum primis in faucibus. Mauris eleifend sagittis mollis. Nulla finibus arcu eu tortor gravida aliquet</p>    
  
                      <a href="#" class="btn btn-primary">Shop now</a>
                  </div>
                  </div>    
           </div>
              <div>
                    <a href="#"><img src="<?php echo e(asset('frontend/image/cache/catalog/slider/slide-2-1920x900.jpg')); ?>" alt="MacBookAir" class="img-responsive center-block"></a>      <div class="slidertext">
                  <div class="slideff">
                      <h1>Organic fresh fruits for your health</h1> 
                      <p>Interdum et malesuada fames ac ante ipsum primis in faucibus. Mauris eleifend sagittis mollis. Nulla finibus arcu eu tortor gravida aliquet</p>    
  
                      <a href="#" class="btn btn-primary">Shop now</a>
                  </div>
                  </div>
             </div>
        
  </div>
  </div>
  
  <script type="text/javascript">
    $('.slideshow').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    arrows: true,
    dots: false,
    autoplaySpeed: 5000,
  });
  </script><?php /**PATH D:\xampp\htdocs\project20\project20\resources\views/frontend/includes/slide.blade.php ENDPATH**/ ?>