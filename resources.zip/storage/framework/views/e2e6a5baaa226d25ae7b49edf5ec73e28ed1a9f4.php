

  <?php echo $__env->make('frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <body>
    

    <div class="wrap">

    
       
        <?php echo $__env->make('frontend.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     

      <section class="site-section py-sm">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <h2 class="mb-4">Latest Posts</h2>
            </div>
          </div>
          <div class="row blog-entries">
            <div class="col-md-12 col-lg-8 main-content">
              <div class="row">
                <?php
                $products = App\Models\Admin\Product::latest()->paginate(10);
              ?>
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-6">
                  <a href="<?php echo e(route('productdetails',$item->id)); ?>" class="blog-entry element-animate" data-animate-effect="fadeIn">
                    <img width="400px;" height="200px;" src="<?php echo e(asset('public/'.$item->photo)); ?>" alt="Image placeholder">
                    <div class="blog-content-body">
                      <div class="post-meta">
                      <span class="ml-2 category"><?php echo e($item->category->category_name); ?> </span>
                        <span class="mr-2"><?php echo e(date('d M Y h:mA',strtotime($item->created_at ))); ?> </span> &bullet;
                   
                      </div>
                      <h2><?php echo e($item->product_name); ?></h2>
                       <p><?php echo Str::limit(strip_tags($item->long_des), 90); ?></p>
                   
                    </div>
                  </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                  
            
              </div>
              <div class="row mt-5">
                <div class="col-md-12 text-center">
                  <?php echo e($products->links('vendor.pagination.custom')); ?>

                </div>
              </div>


             
             
            </div>

            <!-- END main-content -->

           
            <?php echo $__env->make('frontend.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         
            <!-- END sidebar -->

          </div>
        </div>
      </section>
    
      
        
        <?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
      <!-- END footer -->

    </div>
    
    <!-- loader -->
   
        <?php echo $__env->make('frontend.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
  
  </body>
</html><?php /**PATH D:\xampp\htdocs\project20\project20\resources\views/frontend/layouts/admin.blade.php ENDPATH**/ ?>