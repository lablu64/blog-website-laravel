
<?php $__env->startSection('title_admin'); ?>
Admin 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

   <h2 style="text-align: center;"> Admin Dashboard </h2>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project20\project20\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>