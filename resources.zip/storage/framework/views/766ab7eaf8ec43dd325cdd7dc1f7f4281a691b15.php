

<?php $__env->startSection('title_post'); ?>

Antaranga
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project20\project20\resources\views/frontend/dashboard.blade.php ENDPATH**/ ?>