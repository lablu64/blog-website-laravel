

<?php $__env->startSection('title_post'); ?>

<?php echo e($product->product_name); ?>




    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
  <body>
    

    <div class="wrap">

   
    <?php echo $__env->make('frontend.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   

<section class="site-section py-lg">
      <div class="container">
        
        <div class="row blog-entries element-animate">
         
                       

          <div class="col-md-12 col-lg-8 main-content">
                      <img style=" height:536px; width:800px;" src="<?php echo e(asset('public/'.$product->photo)); ?>" alt="" class="img-fluid mb-5">
                      <div class="post-meta">
                                <a class="category mb-5" href="#"><?php echo e($product->category->category_name); ?> </a>
                                  <span class="mr-2"><?php echo e(date('d M Y h:mA',strtotime($product->created_at ))); ?></span>
                                
                                </div>
                      <h1 class="mb-4"><?php echo e($product->product_name); ?></h1>
                                        
                      <div class="post-content-body"><?php echo $product->long_des; ?></div>

      
          </div>

      
          <!-- END main-content -->
         
           <?php echo $__env->make('frontend.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
          
          <!-- END sidebar -->

        </div>
      </div>
    </section>

    <section class="py-5">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h2 class="mb-3 ">Related Post</h2>
          </div>
        </div>
        <div class="row">
          <?php
            $reletade_product = App\Models\Admin\Product::where('category_id',$product->category_id)->latest()->take(3)->get();
          ?>
         
         <?php $__currentLoopData = $reletade_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6 col-lg-4">
            <a href="<?php echo e(route('productdetails',$item->id)); ?>" class="a-block sm d-flex align-items-center height-md" style="background-image: url(<?php echo e(asset('public/'.$item->photo)); ?>); ">
              <div class="text">
                <div class="post-meta">
                  <span class="category"><?php echo e($item->category->category_name); ?></span>
                  <span class="mr-2"><?php echo e(date('d M Y',strtotime($item->created_at ))); ?></span> &bullet;
                 </div>
                <h3><?php echo e($item->product_name); ?></h3>
              </div>
            </a>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
         
          
        </div>
      </div>


    </section>
    <!-- END section -->

             
          

      
    
    
      <?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
      <!-- END footer -->

    </div>
    
    <!-- loader -->
   
      <?php echo $__env->make('frontend.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
  
  </body>
</html><?php /**PATH D:\xampp\htdocs\project20\project20\resources\views/frontend/sigle_page.blade.php ENDPATH**/ ?>