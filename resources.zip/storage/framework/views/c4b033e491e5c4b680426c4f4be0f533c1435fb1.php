
<?php $__env->startSection('title_admin'); ?>
Edit Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>  
      <!-- Content -->

      <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Post /</span> Edit</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
          <!-- Basic Layout -->
          <div class="col-xxl">
            <div class="card mb-4">
              <div class="card-header d-flex align-items-center justify-content-between">
                <h5 class="mb-0">Edit Post </h5>
                <small class="text-muted float-end">input infromation </small>
              </div>
              <div class="card-body">
                <form action="<?php echo e(route('admin.post.update',$product->id)); ?>" method="post" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PATCH'); ?>
                  <div class="mb-3">
                    <label class="form-label" for="product_name">Post Name</label>
                    <input type="text" value="<?php echo e($product->product_name); ?>" name="product_name" class="form-control" id="product_name" />
                  </div>
    
                   <div class="mb-3">
                    <label class="form-label" for="category">Category</label>
                    <select name="category_id"  class="form-control"  id="category">
                        <option value="">Select Category</option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($product->category_id == $item->id? 'selected':''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->category_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
    
                 
    
                  
                  <div class="row mb-3">
                    <label class="col-sm-2 col-form-label" for="basic-default-name"> Old Image</label>
                    <div class="col-sm-10">
                    <img height="100px;" src="<?php echo e(asset($product->photo)); ?>" alt="">
                    <input type="hidden" name="old_photo" value="<?php echo e($product->photo); ?>">
                  </div>
                  </div>
                 <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                  
                  <div class="mb-3">
                    <label for="formFile" class="form-label"> New Upload  Image</label>
                    <input class="form-control" type="file" name="photo" id="photo" />
                  </div>
    
    
                  <div class="mb-3">
                    <label class="form-label" for="long_des">Description</label>
                    <textarea name="long_des"   class="form-control" id="summernote" cols="30" rows="10"><?php echo e($product->long_des); ?></textarea>
                  
                  </div>
    
                 
    
                  
    
              
                <button type="submit" class="btn btn-success">Update Post</button>
              </form>
              </div>
            </div>
          </div>
        
        </div>
      </div>
      <!-- / Content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project20\project20\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>