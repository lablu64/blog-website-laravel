

<?php $__env->startSection('content'); ?>  
<!-- Content -->

<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">All /</span> Brand </h4>
    <a class="btn btn-success mb-2" href="<?php echo e(route('admin.brand.create')); ?>"> Create Brand</a>
   
    <!-- Basic Bootstrap Table -->
    <div class="card">
      <h5 class="card-header">All Brand  </h5>
       <div class="table-responsive text-nowrap">
        <table class="table">
          <thead>
            <tr>
              <th>Sl</th>
              <th>Brand  name</th>
              <th> Cateogry name</th>
              <th>Image</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody class="table-border-bottom-0">


          
            <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                <tr>
                    <td><?php echo e($loop->index+1); ?></td>
                    <td> <i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo e($brand->brand_name); ?></td>
                    <td> <i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo e($brand->category->category_name); ?></td>
                    <td> <img class="" height="100px;" src="<?php echo e(asset($brand->photo)); ?>" alt=""></td>
                    
                    <td class="badge bg-label-<?php echo e($brand->status == 'active'? 'primary':'danger'); ?> me-1"><?php echo e($brand->status); ?></td>
                    <td>
                        <div class="dropdown">
                          <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                            <i class="bx bx-dots-vertical-rounded"></i>
                          </button>
                          <div class="dropdown-menu">
                            <a class="dropdown-item" href="<?php echo e(route('admin.brand.edit',$brand->id)); ?>"
                              ><i class="bx bx-edit-alt me-2"></i> Edit</a>
                            <a class="dropdown-item" href=""
                              ><i class="bx bx-trash me-2"></i> Delete</a>
                          </div>
                        </div>
                      </td>                
                  </tr>
                   
              
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
           
          </tbody>
        </table>
      </div>
    </div>
    <!--/ Basic Bootstrap Table -->
    
    <!--/ Responsive Table -->
  </div>
  <!-- / Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project20\project20\resources\views/admin/brand/index.blade.php ENDPATH**/ ?>