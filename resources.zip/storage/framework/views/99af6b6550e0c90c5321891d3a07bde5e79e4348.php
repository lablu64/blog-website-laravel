<script src="<?php echo e(asset('public/frontend')); ?>/js/jquery-3.2.1.min.js"></script>
    <script src="<?php echo e(asset('public/frontend')); ?>/js/jquery-migrate-3.0.0.js"></script>
    <script src="<?php echo e(asset('public/frontend')); ?>/js/popper.min.js"></script>
    <script src="<?php echo e(asset('public/frontend')); ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('public/frontend')); ?>/js/owl.carousel.min.js"></script>
    <script src="<?php echo e(asset('public/frontend')); ?>/js/jquery.waypoints.min.js"></script>
    <script src="<?php echo e(asset('public/frontend')); ?>/js/jquery.stellar.min.js"></script>

    
    <script src="<?php echo e(asset('public/frontend')); ?>/js/main.js"></script>

<?php /**PATH D:\xampp\htdocs\project20\project20\resources\views/frontend/includes/script.blade.php ENDPATH**/ ?>