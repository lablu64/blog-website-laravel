<?php $__env->startSection('title_post'); ?>

<?php echo e($category->category_name); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <body>
    

    <div class="wrap">





<section class="site-section pt-5">
      <div class="container">
        <div  class="row mb-4">
          <div style="background-color:#dbd8d8; height:150px; " class="col-md-12">   
          
            <h2 style="text-align:center; padding:50px 60px;" class="mb-4 ">Category : <?php echo e($category->category_name); ?> </h2>
          
        
          
          
          </div>
        </div>
        <div class="row blog-entries">
          <div class="col-md-12 col-lg-8 main-content">
            <div class="row mb-5 mt-5">

              <div class="col-md-12">
               
             
               <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
            
                <div class="post-entry-horzontal">
                  <a href="<?php echo e(route('productdetails',$item->id)); ?>">
                    <div class="image element-animate" data-animate-effect="fadeIn" style="background-image: url(<?php echo e(asset('public/'.$item->photo)); ?>);"></div>
                    <span class="text">
                      <div class="post-meta">
                      <span class="mr-2"><?php echo e($item->category->category_name); ?></span> &bullet;
                       
                         <span class="mr-2"><?php echo e(date('d M Y h:mA',strtotime($item->created_at ))); ?></span>
                       
                      </div>
                      <h2><?php echo e($item->product_name); ?></h2>
                    </span>
                  </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
                <!-- END post -->
                <?php echo e($product->links('vendor.pagination.custom')); ?>


              </div>
            </div>

           
         
            

          </div>

          <!-- END main-content -->
        
          
          <!-- END sidebar -->
        
           <?php echo $__env->make('frontend.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
         

        </div>
      </div>
    </section>
  
          
         


      
    
    
     
      <?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
      <!-- END footer -->

    </div>
    
    <!-- loader -->
    
        <?php echo $__env->make('frontend.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
  
  </body>
</html>

 


   
<?php /**PATH D:\xampp\htdocs\project20\project20\resources\views/frontend/category.blade.php ENDPATH**/ ?>