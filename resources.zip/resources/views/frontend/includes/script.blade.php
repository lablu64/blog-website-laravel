<script src="{{ asset('public/frontend') }}/js/jquery-3.2.1.min.js"></script>
    <script src="{{ asset('public/frontend') }}/js/jquery-migrate-3.0.0.js"></script>
    <script src="{{ asset('public/frontend') }}/js/popper.min.js"></script>
    <script src="{{ asset('public/frontend') }}/js/bootstrap.min.js"></script>
    <script src="{{ asset('public/frontend') }}/js/owl.carousel.min.js"></script>
    <script src="{{ asset('public/frontend') }}/js/jquery.waypoints.min.js"></script>
    <script src="{{ asset('public/frontend') }}/js/jquery.stellar.min.js"></script>

    
    <script src="{{ asset('public/frontend') }}/js/main.js"></script>

