
{{-- 
<footer class="site-footer">
        <div class="container">
         
          <div class="row">
            <div class="col-md-12 text-center">
              <p class="small">
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy; <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> All Rights Reserved
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
            </div>
          </div>
        </div>

</footer> --}}
<html>
  <head>
  

  </head>
  <footer class="footer" style="background-color: #F2F3F4;">
            <div class="container">
                <div class="row">
                    <p class="text-center">
                        <a href="{{ url('/home') }}" class="gototop" style="margin:0px 500px;"><i class="fa fa-angle-double-up fa-2x"></i></a>
                    </p>
                	<div class="col-12">
                    	 <h3 class="text-center" style="color: red; margin-bottom: 50px;">Get In Touch With Us</h3>
                    </div>
                    
                    <div class="col-4">
                        <div class="widget widget-address">
                            <div class="address-box">
                                <div class="logo">
                                    <img src="{{ asset('public/upload/logo.png') }}" alt="Internet Service Provider in Bangladesh" style="width:100px;height:100px;>                                 
                                </div>
                                <div class="text-black"> 
                                    <h2 class="fs-3">antaranga dot com limited</h2>                                 
                                 <p></p>
                                </div>
                                <div class="dhaka-address">
                                    <h2 class="fs-5">Corporate Office - Dhaka</h2>
                                     24/1, Shan Tower(3rd floor), Shantinagar More,
                                     Polton, Dhaka- 1217, Dhaka
                                 </div>
                                 <div class="chattogram-address">
                                     <h2 class="fs-5">Corporate Office -Chattogram</h2>
                                     Tower- 71 (23rd floor),<br>
                                     Agrabad C/A, Chattogram
                                 </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-4" style="text-align: center;">
                        <div class="widget widget-address">
                            <address>
                            	<strong class="address-text"><font size="3" color="red">Other Pages</font></strong><br>  
                            	   
                                   <div class="footer-icone" style="padding: 5px; margin-left: 125px;">
                                    <div class="d-flex">
                                        <span class="d-flex"style="font-size: 13px; margin-top: 4px; color: red">
                                            <i class="fa fa-check-circle"></i>
                                  
                                        </span>
                                        <h3 class="items-text fs-6" style="margin-left: 5px;">About Us</h3>
                                        
                                    </div>
                                      <div class="d-flex">
                                        <span class="icone-check"style="font-size: 13px; margin-top: 4px; color: red">
                                            <i class="fa fa-check-circle"></i>
                                    
                                        </span>
                                        <h3 class="items-text fs-6" style="margin-left: 5px;">Package </h3>
                                         <a href=""></a>
                                    </div>
                                      <div class="d-flex">
                                        <span class="icone-check" style="font-size: 13px; margin-top: 4px; color: red"> 
                                            <i class="fa fa-check-circle"></i>
                                        </span>
                                        <h3 class="items-text fs-6" style="margin-left: 5px;">Coverage</h3>
                                        <a href="coverage.php"></a>
                                    </div>

                                      <div class="d-flex">
                                        <span class="icone-check"style="font-size: 13px; margin-top: 4px; color: red">
                                            <i class="fa fa-check-circle"></i>
                                        </span>
                                        <h3 class="items-text fs-6" style="margin-left: 5px;">Contact</h3>
                                        <a href="contact.php"></a>
                                    </div>
                                    <div class="d-flex">
                                        <span class="icone-check" style="font-size: 13px; margin-top: 4px; color: red"> 
                                            <i class="fa fa-check-circle"></i>
                                        </span>
                                        <a class="items-text fs-6" href="{{ route('logout') }}" style="margin-left: 5px;">logout</a>
                                        
                                    </div>
                                </div>                            
                            </address>
                        </div>                     
                    </div>
                    <div class="col-4">
                        <div class="widget widget-address">
                            <address>
                            	<strong class="address-contact"><font size="3" color="red">Contact Us</font></strong><br>                            
                                <span  class="Hotline" style="display: block;"><img src="images/about-img/callcenter.png" alt=""><strong>Hotline: 09613-121-131, 09613-131-131</strong></span>

                                <span class="d-flex"><i class="fa fa-volume-control-phone" style="color: red; font-size: 13px; padding-top: 6px; margin-bottom: 0px;" aria-hidden="true"></i>
                                <strong class="fs-6" style="margin-left: 10px; color: block;margin-bottom: 8px">Phone: 01711-669900</strong></span>

                                <span class="d-flex"><i class="fa fa-envelope" style="color: red; font-size: 13px;padding-top: 6px;" aria-hidden="true"></i>
                                <strong class="fs-6" style="margin-left: 10px;margin-bottom: 8px">Email: info@antbd.com</span>
                            </address>
                        </div>                     
                    </div>
                </div>
            </div>

			
			<br>
        </footer>
        
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script></html>   
 