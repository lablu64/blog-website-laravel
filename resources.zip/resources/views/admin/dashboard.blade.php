@extends('admin.layouts.index')
@section('title_admin')
Admin 
@endsection

@section('content')

   <h2 style="text-align: center;"> Admin Dashboard </h2>


@endsection